<?php

/**
 * includes/head.php — Shared <head> partial for all LibraLink pages
 *
 * Usage (root pages):     require_once __DIR__ . '/includes/head.php';
 * Usage (sub-dirs):       require_once __DIR__ . '/../includes/head.php';
 *
 * Variables consumed:
 *   $pageTitle  (string, optional) — page <title>; defaults to 'LibraLink'
 *   BASE_URL    (constant)        — defined in config.php via db.php
 */
?>
<?php
$extraStyles = isset($extraStyles) && is_array($extraStyles) ? $extraStyles : [];
$extraScripts = isset($extraScripts) && is_array($extraScripts) ? $extraScripts : [];
$includeSweetAlert = array_key_exists('includeSweetAlert', get_defined_vars()) ? (bool) $includeSweetAlert : true;
?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle ?? 'LibraLink', ENT_QUOTES, 'UTF-8') ?></title>
<link rel="icon" href="<?= BASE_URL ?>assets/images/favicon.svg" type="image/svg+xml">

<?php if ($includeSweetAlert): ?>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<?php endif; ?>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/libris.css">
<?php foreach ($extraStyles as $styleHref): ?>
  <?php if (is_string($styleHref) && $styleHref !== ''): ?>
    <link rel="stylesheet" href="<?= htmlspecialchars($styleHref, ENT_QUOTES, 'UTF-8') ?>">
  <?php endif; ?>
<?php endforeach; ?>

<!--
  Compatibility bootstrap is loaded first (non-deferred) so legacy-safe polyfills
  are in place before third-party scripts and deferred app bundles execute.
  It also exposes window.LibrisCompat feature flags for progressive degradation.
-->
<script src="<?= BASE_URL ?>assets/js/libris-compat.js"></script>

<?php if ($includeSweetAlert): ?>
  <!-- Keep SweetAlert globally available for existing inline/scripted usage. -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
  <script src="<?= BASE_URL ?>assets/js/sweetalert-utils.js" defer></script>
<?php endif; ?>
<script src="<?= BASE_URL ?>assets/js/sidebar-mobile.js" defer></script>
<?php foreach ($extraScripts as $extraScript): ?>
  <?php
  $scriptSrc = '';
  $scriptDefer = true;
  if (is_string($extraScript)) {
    $scriptSrc = $extraScript;
  } elseif (is_array($extraScript)) {
    $scriptSrc = isset($extraScript['src']) && is_string($extraScript['src']) ? $extraScript['src'] : '';
    if (array_key_exists('defer', $extraScript)) {
      $scriptDefer = (bool) $extraScript['defer'];
    }
  }
  ?>
  <?php if ($scriptSrc !== ''): ?>
    <script src="<?= htmlspecialchars($scriptSrc, ENT_QUOTES, 'UTF-8') ?>" <?= $scriptDefer ? ' defer' : '' ?>></script>
  <?php endif; ?>
<?php endforeach; ?>
