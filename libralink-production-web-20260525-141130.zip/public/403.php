<?php
// Thin wrapper to the canonical entry file in project root.
require_once __DIR__ . '/../403.php';
